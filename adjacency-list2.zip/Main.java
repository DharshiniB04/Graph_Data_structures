class Node {
    int data;
    Node next;
    public Node(int d) {
        data = d;
        next = null;
    }
}
class Graph {
    int V; 
    Node[] adjList; 
    public Graph(int V) {
        this.V = V;
        adjList = new Node[V];
        for (int i = 0; i < V; i++) {
            adjList[i] = null;
        }
    }
    public void addEdge(int src, int dest) {
        Node newNode = new Node(dest);
        newNode.next = adjList[src];
        adjList[src] = newNode;
        newNode = new Node(src);
        newNode.next = adjList[dest];
        adjList[dest] = newNode;
    }


    public void BFS(int s) {
        boolean[] visited = new boolean[V];
        int[] queue = new int[V]; 
        int front = 0, rear = 0;

        visited[s] = true;
        queue[rear++] = s;

        while (front < rear) {
            int cv = queue[front++];
            System.out.print(cv + " ");

            Node cn = adjList[cv];
            while (cn != null) {
                int adj = cn.data;
                if (!visited[adj]) {
                    visited[adj] = true;
                    queue[rear++] = adj;
                }
                cn = cn.next;
            }
        }
    }
     public void DFS(int source) 
    {
        boolean[] visited = new boolean[V];
        DFSRecursive(source, visited);
    }
    private void DFSRecursive(int vertex, boolean[] visited) 
    {
        visited[vertex] = true;
        System.out.print(vertex + " ");
        Node current = adjList[vertex];
        while (current != null) 
        {
            int neighbor = current.data;
            if (!visited[neighbor]) 
            {
                DFSRecursive(neighbor, visited);
            }
            current = current.next;
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Graph graph = new Graph(6);
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 3);
        graph.addEdge(2, 3);
        graph.addEdge(2, 4);
        graph.addEdge(3, 4);
        graph.addEdge(3, 5);
        graph.addEdge(4, 5);
        graph.DFS(0);
        graph.BFS(0);
    }
}
