/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
    static int mat[][];
    public int v;
    public Main(int v){
        this.v=v;
        mat=new int[v][v];
    }
    public void addEdge(int s, int d){
        mat[s][d]=1;
        mat[d][s]=1;
    }
    
    public void printMat(){
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                System.out.print(mat[i][j]+" ");
            }
            System.out.println();
        }
        
    }
    
	public static void main(String[] args) {
		Main g=new Main(4);
		g.addEdge(0,1);
		g.addEdge(0,2);
		g.addEdge(1,2);
		g.addEdge(2,0);
		g.addEdge(2,3);
		g.printMat();
	}
}
